$P = Get-Process
Write-Output $P
