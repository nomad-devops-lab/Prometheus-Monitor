# automation-account

This repository contains Terraform module that deploys Azure Automation Account and related resources.

# Pre-requisites
- Terraform version 1.0.0
- Azure resource group
# Variables

| Name |  |  | Type | Description |
|---|---|---|---|---|
| resource_group_name |  |  | string | The name of the resource group in which to create the automation account and other resources. |
| location |  |  | string | Azure location in which to create the automation account. Defaults to `eastus2`. |
| automation_account_name | | | string | Name of the automation account to create. |
| automation_account_sku | | | string | The name of the SKU to use for automation account. |
| public_network_access_enabled | | | bool | Whether public network access is allowed for the automation account. Defaults to `true`.|
| additional_tags |  |  | map of strings | Common tags that should be applied to the automation account that gets created.<br>In addition to the tags that are already assigned to the resource group. |
| Credential |  |  | object | Each object accepts the arguments described below. |
|  | name |  | string | The name of the credentials to be created. |
|  | username |  | string | Username for the credential |
|  | password |  | string | Password for the credential. |
|  | description |  | string | Description of the credential. |
| runbooks | | | map of objects | Each object accepts the arguments described below. |
| | name | | string | Name of the runbook. |
| | type | | string | The type of the runbook. Possible values are Graph, GraphPowerShell, GraphPowerShellWorkflow, PowerShellWorkflow, PowerShell and script.|
| | log_verbose| | bool | Weather to enable verbose log. Defaults to false. |
| | log_progress | | bool | Weather to enable progress log. Defaults to false. |
| | content_file | | string | Name and path of the content file. Should only be used if the content is locally stored. |
| | content_link | | string | Link to the runbook content. Should only be used if the content is remotely stored. |
| | additional_tags | | map of strings | A map of additional tags to assign to this runbook. Will inherit all the tags from resource groups by default.|
| | description | | string | A description of this runbook. |
| schedules | | | map of objects | Each object accepts the arguments described below.|
| | name | | string | Name of the schedule. |
| | frequency | | string | The frequency of the schedule - can be either OneTime, Day, Hour, Week or Month.|
| | interval | | string | The number of frequencys between runs. Only valid when frequecy is Day, Hour, Week or Month and defaults to 1.|
| | start_time | | string | Start time of the schedule. Must be at least five minutes in the future. |
| | expiry_time | | string | The end time of the schedule. | 
| | time_zone | | string | The timezone of the start time. Defaults to UTC. | 
| | week_days | | list of strings | List of days of the week that the job should execute on. Only valid when frequency is Week.| 
| | month_days | | list of strings  | List of days of the month that the job should execute on. Must be between 1 and 31. -1 for the last day of the month. Only valid when frequency is Month. |
| | monthly_occurrence | | list of objects | Each object accepts the arguments described below.|
| | | day | string | Day of the occurrence. |
| | |occurrence | string | occurrence of the week within the month. Must be between 1 and 5. -1 for last week within the month. | 
| | description | | string | A description for this schedule. |
| link_schedules | | | map of objects | Each object accepts the arguments described below.|
| | schedule_name | | string | Name of the schedule that needs to be linked to the runbook.|
| | runbook_name | | string | Name of the runbook that needs to be linked to the schedule. | 
| | parameters | | map of strings | A map of parameters that needs to be passed to the runbook. | 
| | run_on | | string | Name of the Hybrid Worker group that Runbook will be executed on. |
| webhooks | | | map of objects | Each object accepts the arguments described below. |
| | name | | string | The name of the webhook. |
| | runbook_name | | string | Name of the runbook to be executed by this webhook. | 
| | expiry_time | | string | Timestamp when the webhook expires. Changing this forces a new resource to be created.|
| | run_on | | string | Name of the hybrid worker group the Webhook job will run on.|
| | parameters | | map of strings |  Map of input parameters passed to runbook. | 


# Usage
An example of how to use this module can be found in the Example folder.

```terraform
module "automation-account" {
  source  = "git.xit.rxcorp.com/ccoe/automation-account/azure"

  resource_group_name     = "test-rg"
  location                = "eastus2"
  automation_account_name = "testAutomationAccount"

  runbooks = {
    runbook1 = {
        name         = "testRunbook"
        type         = "PowerShell"
        log_verbose  = false
        log_progress = true

        content_file = "./example.ps1"
        //content_file = null

        content_link = null
        //content_link = "https://raw.githubusercontent.com/Azure/azure-quickstart-templates/c4935ffb69246a6058eb24f54640f53f69d3ac9f/101-automation-runbook-getvms/Runbooks/Get-AzureVMTutorial.ps1"

        additional_tags = {}
        description     = "Testing runbook creation with Terraform"
    }
  }
  credential = {
    name     = "testCredentials"
    username = "testUser"
    password = "testPassword"
  }
  schedules = {
    schedule1 = {
        name               = "testSchedule"
        frequency          = "OneTime"
        interval           = null
        start_time         = null
        expiry_time        = null
        time_zone          = null
        week_days          = null
        month_days         = null
        monthly_occurrence = []
        description        = "test schedule"
    }
  }
  link_schedules = {
    link1 = {
        schedule_name = "testSchedule"
        runbook_name  = "testRunbook"
        parameters    = {}
        run_on        = null
    }
  }
  webhooks = {
    webhook1 = {
        name = "testWebhook"
        runbook_name = "testRunbook"
        expiry_time = "2023-12-31T00:00:00Z"
        run_on = null
        parameters = {}
    }
  }
}
```

Example above pulls the child module from Gitlab's Terraform registry. For it to work you will need to configure credentials in `~/.terraformrc` file.
```bash
credentials "git.xit.rxcorp.com" {
    token = "<access-token>"
}
```

## Release
The `.gitlab-ci.yml` file contains a pipeline job called `upload` which gets triggered when a tag is created. The purpose of that job is to create a new release and upload the latest version of this module to the Gitlab's infrastructure registry. Once the job executes successfully the latest release of the module is ready for consumption.

> When creating a new tag make sure to follow semantic versioning.

## Enhancements
If you would like to update, modify or enhance this repository please submit a pull request.

## Maintainer
<a href="mailto:prakash.upreti@iqvia.com">Prakash Upreti</a>
